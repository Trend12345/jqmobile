$(function(){
	var save = $('.save'),
	del = $('.del');

	save.on('click', function(){
		console.log("save")
	});

	del.on('click', function(){
		console.log("delete")
	});

	$('.img').on('click', function(){
		 navigator.geolocation.getCurrentPosition(function(position) {
		      var lat = position.coords.latitude;
	    	  var lng = position.coords.longitude;

		      $('.latitude').text(lat.toFixed(3));
	    	  $('.longitude').text(lng.toFixed(3));

	    });

		console.log('Hello')
	})


	

})